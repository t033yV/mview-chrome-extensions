let isMobileViewActive = false;
let originalStyles = {};
let mobileFrame = null;

// Listen for messages from popup
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === "toggle") {
    if (isMobileViewActive) {
      deactivateMobileView();
    } else {
      activateMobileView(request.width);
    }
    sendResponse({active: isMobileViewActive});
  } else if (request.action === "getState") {
    sendResponse({active: isMobileViewActive});
  }
  return true;
});

function activateMobileView(width) {
  // Save original styles
  originalStyles = {
    bodyWidth: document.body.style.width,
    bodyMargin: document.body.style.margin,
    bodyOverflow: document.body.style.overflow
  };
  
  // Create container for split view
  const container = document.createElement('div');
  container.id = 'mobile-view-container';
  container.style.display = 'flex';
  container.style.height = '100vh';
  container.style.width = '100vw';
  container.style.position = 'fixed';
  container.style.top = '0';
  container.style.left = '0';
  container.style.zIndex = '9999';
  container.style.backgroundColor = '#f0f0f0';
  
  // Create desktop view
  const desktopView = document.createElement('div');
  desktopView.id = 'desktop-view';
  desktopView.style.flex = '1';
  desktopView.style.overflow = 'auto';
  desktopView.style.height = '100%';
  desktopView.style.borderRight = '1px solid #ccc';
  
  // Create mobile view
  const mobileView = document.createElement('div');
  mobileView.id = 'mobile-view';
  mobileView.style.width = `${width}px`;
  mobileView.style.height = '100%';
  mobileView.style.overflow = 'hidden';
  mobileView.style.backgroundColor = '#fff';
  mobileView.style.position = 'relative';
  
  // Create iframe for mobile view
  mobileFrame = document.createElement('iframe');
  mobileFrame.id = 'mobile-frame';
  mobileFrame.src = window.location.href;
  mobileFrame.style.width = '100%';
  mobileFrame.style.height = '100%';
  mobileFrame.style.border = 'none';
  
  // Add mobile user agent to the iframe
  mobileFrame.onload = function() {
    try {
      // Attempt to inject a script to override navigator.userAgent
      const script = document.createElement('script');
      script.textContent = `
        Object.defineProperty(navigator, 'userAgent', {
          get: function() {
            return 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1';
          }
        });
      `;
      mobileFrame.contentDocument.head.appendChild(script);
    } catch (e) {
      console.error('Failed to override user agent in iframe:', e);
    }
  };
  
  // Clone the current document to the desktop view
  const currentContent = document.documentElement.cloneNode(true);
  desktopView.appendChild(currentContent);
  
  // Build the container structure
  mobileView.appendChild(mobileFrame);
  container.appendChild(desktopView);
  container.appendChild(mobileView);
  
  // Hide the original page content
  document.body.style.overflow = 'hidden';
  
  // Insert the container
  document.body.appendChild(container);
  
  isMobileViewActive = true;
}

function deactivateMobileView() {
  const container = document.getElementById('mobile-view-container');
  if (container) {
    container.remove();
  }
  
  // Restore original styles
  document.body.style.width = originalStyles.bodyWidth;
  document.body.style.margin = originalStyles.bodyMargin;
  document.body.style.overflow = originalStyles.bodyOverflow;
  
  isMobileViewActive = false;
}