document.addEventListener('DOMContentLoaded', function() {
    const toggleButton = document.getElementById('toggleButton');
    const reloadButton = document.getElementById('reloadButton');
    const screenshotButton = document.getElementById('screenshotButton');
    const viewportWidthInput = document.getElementById('viewportWidth');
    const statusDiv = document.getElementById('status');
    
    // Check current state and update toggle button text
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      chrome.tabs.sendMessage(tabs[0].id, {action: "getState"}, function(response) {
        if (response && response.active) {
          toggleButton.textContent = "Deactivate Split View";
          toggleButton.classList.add('active');
        } else {
          toggleButton.textContent = "Activate Split View";
          toggleButton.classList.remove('active');
        }
      });
    });
    
    // Load saved viewport width
    chrome.storage.sync.get(['viewportWidth'], function(result) {
      if (result.viewportWidth) {
        viewportWidthInput.value = result.viewportWidth;
      }
    });
    
    // Toggle split view
    toggleButton.addEventListener('click', function() {
      const width = parseInt(viewportWidthInput.value) || 375;
      
      // Save viewport width
      chrome.storage.sync.set({viewportWidth: width});
      
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: "toggle", 
          width: width
        }, function(response) {
          if (response) {
            toggleButton.textContent = response.active ? 
              "Deactivate Split View" : "Activate Split View";
            
            if (response.active) {
              toggleButton.classList.add('active');
              showStatus("Split view activated");
            } else {
              toggleButton.classList.remove('active');
              showStatus("Split view deactivated");
            }
          }
        });
      });
    });
    
    // Reload page
    reloadButton.addEventListener('click', function() {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.reload(tabs[0].id);
        showStatus("Page reloaded");
      });
    });
    
    // Take screenshot
    screenshotButton.addEventListener('click', function() {
      chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.captureVisibleTab(function(dataUrl) {
          // Create a download for the screenshot
          const timestamp = new Date().toISOString().replace(/:/g, '-');
          chrome.downloads.download({
            url: dataUrl,
            filename: `screenshot-${timestamp}.png`,
            saveAs: true
          });
          showStatus("Screenshot taken");
        });
      });
    });
    
    function showStatus(message) {
      statusDiv.textContent = message;
      setTimeout(() => {
        statusDiv.textContent = '';
      }, 3000);
    }
  });